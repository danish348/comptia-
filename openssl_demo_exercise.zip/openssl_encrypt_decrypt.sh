#!/bin/bash

# Define file names
PLAINTEXT="message.txt"
ENCRYPTED="message.enc"
DECRYPTED="message_decrypted.txt"
KEY="secret.key"

# Step 1: Generate a key (in real-world cases use secure key management)
echo "my_secure_password" > $KEY

# Step 2: Encrypt the file
openssl enc -aes-256-cbc -salt -in $PLAINTEXT -out $ENCRYPTED -pass file:$KEY
echo "Encryption complete. Encrypted file: $ENCRYPTED"

# Step 3: Decrypt the file
openssl enc -d -aes-256-cbc -in $ENCRYPTED -out $DECRYPTED -pass file:$KEY
echo "Decryption complete. Decrypted file: $DECRYPTED"

# Step 4: Show original and decrypted files
echo "--- Original Message ---"
cat $PLAINTEXT
echo "--- Decrypted Message ---"
cat $DECRYPTED
